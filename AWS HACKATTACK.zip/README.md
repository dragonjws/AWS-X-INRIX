
  # AWS HACKATTACK

  This is a code bundle for AWS HACKATTACK. The original project is available at https://www.figma.com/design/8dk2J3EkZ66xHKtXEdwcSZ/AWS-HACKATTACK.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  